 <div class="row"  ng-controller="squad">
    <div class="col-xl-2 col-md-4">
      <div class="card card-stats border border-primary node " data-info="new">
        <!-- Card body -->
        <a href="<?php echo base_url('recharge/mobile')?>">
        <div class="card-body">
            <div class="row">
                <div class="col-12 text-center text-info"> <i class="fa fa-mobile fa-5x" aria-hidden="true"></i></div>
            </div>
                <div class="row">
                <div class="col-12 text-center text-info"> MOBILE</div>
            </div>        
        </div>
        </a>
      </div>
    </div>
    <div class="col-xl-2 col-md-4">
      <div class="card card-stats border border-primary" data-info="new">
        <!-- Card body -->
         <a href="<?php echo base_url('recharge/dth')?>">
        <div class="card-body">
         <div class="row">
                <div class="col-12 text-center text-info"> <i class="fa fa-desktop fa-5x" aria-hidden="true"></i></div>
            </div>
                <div class="row"> 
                <div class="col-12 text-center text-info"> DTH</div>
            </div>

        </div>
        </a>
      </div>
    </div>
     <div class="col-xl-2 col-md-4">
      <div class="card card-stats border border-primary node" data-info="new">
        <!-- Card body -->
         <a href="<?php echo base_url('recharge/datacard')?>">
        <div class="card-body">
         <div class="row">
                <div class="col-12 text-center text-info"> <i class="fa fa-wifi fa-5x" aria-hidden="true"></i></div>
            </div>
                <div class="row">
                <div class="col-12 text-center text-info"> DATA CARD</div>
            </div>
        </div>
        </a>
      </div>
    </div>
     <div class="col-xl-2 col-md-4">
      <div class="card card-stats border border-primary node" data-info="new">
        <!-- Card body -->  <a href="<?php echo base_url('recharge/landline')?>">
        <div class="card-body">
        <div class="row">
                <div class="col-12 text-center text-info"> <i class="fa fa-phone fa-5x" aria-hidden="true"></i></div>
            </div>
                <div class="row">
                <div class="col-12 text-center text-info"> LANDLINE</div>
            </div>
        </div> </a>
      </div>
    </div>
     <div class="col-xl-2 col-md-4">
      <div class="card card-stats border border-primary node" data-info="new">
        <!-- Card body -->  <a href="<?php echo base_url('recharge/electricity')?>">
        <div class="card-body">
        <div class="row">
                <div class="col-12 text-center text-info"> <i class="fa fa-bolt fa-5x" aria-hidden="true"></i></div>
            </div>
                <div class="row">
                <div class="col-12 text-center text-info"> ELECTRiCITY</div>
            </div>
        </div> </a>
      </div>
    </div>
     <div class="col-xl-2 col-md-4">
      <div class="card card-stats border border-primary node" data-info="new">
        <!-- Card body -->  <a href="<?php echo base_url('recharge/gas')?>">
        <div class="card-body">
        <div class="row">
                <div class="col-12 text-center text-info"> <i class="fa fa-fire fa-5x" aria-hidden="true"></i></div>
            </div>
                <div class="row">
                <div class="col-12 text-center text-info"> GAS</div>
            </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
      <div class="col-xl-2 col-md-4">
      <div class="card card-stats border border-primary node" data-info="new">
        <!-- Card body -->  <a href="<?php echo base_url('recharge/water')?>">
        <div class="card-body">
        <div class="row">
                <div class="col-12 text-center text-info"> <i class="fa fa-bath fa-5x" aria-hidden="true"></i></div>
            </div>
                <div class="row">
                <div class="col-12 text-center text-info"> WATER</div>
            </div>
        </div> </a>
      </div>
    </div>
    <div class="col-xl-2 col-md-4">
      <div class="card card-stats border border-primary node" data-info="new">
        <!-- Card body -->  <a href="<?php echo base_url('recharge/insurance')?>">
        <div class="card-body">
        <div class="row">
                <div class="col-12 text-center text-info"> <i class="fa fa-umbrella fa-5x" aria-hidden="true"></i></div>
            </div>
                <div class="row">
                <div class="col-12 text-center text-info"> INSURANCE</div>
            </div>
        </div>
      </div> </a>
    </div>
  </div>
 