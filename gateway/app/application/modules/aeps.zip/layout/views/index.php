<?php get_section('layout/css'); ?>
<!-- Main content -->
<div class="main-content" id="panel">
  <!-- Topnav -->


  <!-- Header -->
  <?php get_section('layout/header'); ?>
  <!-- Header -->
  <!-- Main Containt -->
  <!-- Page content -->
  <div class="container-fluid mt--6">

    <?php echo $main_content ?>

    <!-- Footer -->
    <?php get_section('layout/footer'); ?>

  </div>
</div>

<!-- script -->
<?php get_section('layout/script'); ?>
<!-- script -->
