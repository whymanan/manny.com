 <div class="row">
   <div class="col-xl-12">
     <div class="card">
       <div class="card-header border-0">
         <div class="row align-items-center">
           <div class="col">
             <h3 class="mb-0">New Join</h3>
           </div>
           <div class="col text-right">
             <a href="#!" id="notify" class="btn btn-sm btn-primary">See all</a>
           </div>
         </div>
       </div>
       <div class="table-responsive">
         <!-- Projects table -->
         <table class="table align-items-center table-flush" id="squadlist">
           <thead class="thead-light">
             <tr>
               <th scope="col">#</th>
               <th scope="col">NAME</th>
               <th scope="col">PHONE</th>
               <th scope="col">VENDOR</th>
               <th scope="col">CITY</th>
               <th scope="col">STATUS</th>
               <th scope="col">KYC</th>
               <th scope="col">Join Date</th>
              </tr>
           </thead>
         </table>
       </div>
     </div>
   </div>
 </div>
