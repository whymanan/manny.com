<div class="row">

    <div class="col-xl-12 order-xl-1">
        <div class="card">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col-8">
                        <h3 class="mb-0">AePS Services Commision</h3>
                    </div>
                    <div class="col-4 text-right">

                    </div>
                </div>
            </div>
            <div class="card-body">
              <div class="pl-lg-6">
                  <div class="row">
                      <div class="col-lg-4">
                          <div class="form-group">
                              <label class="form-control-label">Select Package</label>
                              <select name="user_role" id="role" class="form-control" required>
                                  <option value="">Select Role</option>
                              </select>
                          </div>
                      </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-12">
                      <div id="addCommissionForm"></div>
                    </div>
                  </div>
              </div>
            </div>
        </div>
    </div>
</div>
