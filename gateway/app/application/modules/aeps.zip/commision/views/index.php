     <div class="row">
         <div class="col-xl-12">
             <div class="card">
                 <div class="card-header border-0">
                     <div class="row align-items-center">
                         <div class="col">
                             <h3 class="mb-0">New Join</h3>
                         </div>
                         <div class="col text-right">
                             <a href="#!" id="notify" class="btn btn-sm btn-primary">See all</a>
                         </div>
                     </div>
                 </div>
                 <div class="table-responsive">
                     <!-- Projects table -->
                     <table class="table align-items-center table-flush" id="squadlist">
                         <thead class="thead-light">
                             <tr>
                                 <th scope="col">#</th>
                                 <th scope="col">NAME</th>
                                 <th scope="col">Role</th>
                                 <th scope="col">CREATED AT</th>
                                 <th scope="col">View</th>
                                 <th scope="col">Delete</th>
                             </tr>
                         </thead>
                         <tbody>
                             <?php $i=1;
                             foreach($commision as $row){?>
                             <tr>
                             <td><?php echo $i?></td>
                             <td><?php echo $row['name']?></td>
                             <td><?php echo $row['role']?></td>
                             <td><?php echo $row['created_at']?></td>
                             <td> <a
                                     href="<?php  base_url('commision/view?q=') . $row['service_commission_main_id'] ?>">
                                     <button type="button" class="btn btn-sm btn-secondary" data-placement="bottom"
                                         title="Edit Menu Information"><i class="fa fa-pencil-alt"></i></button></a>
                             </td>
                             <td>
                                     <button type="button" class="btn btn-sm btn-danger" data-placement="bottom"
                                         title="delete"><i class="fa fa-trash"></i></button>
                             </td></tr>
                             <?php $i++;} ?>
                         </tbody>
                     </table>
                 </div>
             </div>
         </div>
     </div>