
<script type="text/javascript">

    EmoApp.controller('AepsBanks2', function( $scope, $http ) {

      $scope.aepsTransactionPanel = document.querySelector('#aepsTransactionPanel');
      $scope.bankCode = '';
      $scope.bankList = [];

      var $api = '<?php echo 'https://emopay.co.in/vite/pay/banklist'; ?>';

      var $token = '<?php echo  $this->session->userdata('token') ?>';

      $http.get($api, {
        headers: {
          'Content-Type': 'application/json',
           'Authorization': 'Bearer ' + $token
        }
      }) .then(function (response) {

        $scope.bankList = response.data.banklist.data;

      }, function (response) {});


    });


</script>
