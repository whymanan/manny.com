

<div class="container">
        <div class="row">
              <div class="col-lg">
                    <div class="card bg-gradient-default">
                    <div class="card-body">
                      <h3 class="card-title text-white">Emopay PVT. LTD</h3>
                      <blockquote class="blockquote text-white mb-0">
                        <p>Account Name: Emopay <br> Account No: ......XXXX <br>  IFSC Code: ....XXXXX</p>
                        <!--<footer class="blockquote-footer text-danger">Someone famous in <cite title="Source Title">Source Title</cite></footer>-->
                      </blockquote>
                    </div>
                </div>
          </div>
     </div>
</div>     