
                    <div class="row">
        <div class="col-xl-3">
          <!--* Card header *-->
          <!--* Card body *-->
          <!--* Card init *-->
          
        </div>
        <div class="col-xl-6">
          <!--* Card header *-->
          <!--* Card body *-->
          <!--* Card init *-->
          <div class="card">
            <!-- Card header -->
            <div class="card-header">
              <!-- Surtitle -->
              <h4 class="surtitle text-center text-danger">Error</h4>
              <!-- Title -->
              <h6 class="surtitle text-center">Insufficient Balance</h6>
            </div>
            <!-- Card body -->
            <div class="card-body text-center">
             <a class="link " href="<?php echo base_url('wallet/add')?>">Add Balance </a>
            </div>
          </div>
        </div>
        <div class="col-xl-3">
          <!--* Card header *-->
          <!--* Card body *-->
          <!--* Card init *-->
        
        </div>
      </div>
    
     
    </div>
  </div>
</div>
