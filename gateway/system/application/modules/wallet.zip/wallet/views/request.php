 <div class="row"  ng-controller="squad">
    <div class="col-xl-3 col-md-6">
      <div class="card card-stats border-0 node" data-info="to">
        <!-- Card body -->
        <div class="card-body">
          <div class="row">
            <div class="col">
              <h5 class="card-title text-uppercase mb-0">Requested To</h5>
              <span class="h2 font-weight-bold mb-0">{{to}}</span>
            </div>
            <div class="col-auto">
              <div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                <i class="ni ni-single-02"></i>
              </div>
            </div>
          </div>
          <p class="mt-3 mb-0 text-sm">
            <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
            <span class="text-nowrap">Since last month</span>
          </p>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6">
      <div class="card card-stats node border-0" data-info="from">
        <!-- Card body -->
        <div class="card-body">
          <div class="row">
            <div class="col">
              <h5 class="card-title text-uppercase text-muted mb-0">Requested From</h5>
              <span class="h2 font-weight-bold mb-0">{{from}}</span>
            </div>
            <div class="col-auto">
              <div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow">
                <i class="ni ni-circle-08"></i>
              </div>
            </div>
          </div>
          <p class="mt-3 mb-0 text-sm">
            <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
            <span class="text-nowrap">Since last month</span>
          </p>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-md-6">
      <div class="card card-stats border-0 node" data-info="new">
        
        <div class="card-body">
          <div class="row">
            <div class="col">
              <h5 class="card-title text-uppercase text-muted mb-0">New Request</h5>
              <span class="h2 font-weight-bold mb-0">{{new}}</span>
            </div>
            <div class="col-auto">
              <div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                <i class="ni ni-user-run"></i>
              </div>
            </div>
          </div>
          <p class="mt-3 mb-0 text-sm">
            <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
            <span class="text-nowrap">Since last month</span>
          </p>
        </div>
      </div>
    </div>
    <!--<div class="col-xl-3 col-md-6">-->
    <!--  <div class="card card-stats border-0 node" data-info="pending">-->
        <!-- Card body -->
    <!--    <div class="card-body">-->
    <!--      <div class="row">-->
    <!--        <div class="col">-->
    <!--          <h5 class="card-title text-uppercase text-muted mb-0">Pending</h5>-->
    <!--          <span class="h2 font-weight-bold mb-0">{{pending}}</span>-->
    <!--        </div>-->
    <!--        <div class="col-auto">-->
    <!--          <div class="icon icon-shape bg-gradient-info text-white rounded-circle shadow">-->
    <!--            <i class="ni ni-chart-bar-32"></i>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--      <p class="mt-3 mb-0 text-sm">-->
    <!--        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>-->
    <!--        <span class="text-nowrap">Since last month</span>-->
    <!--      </p>-->
    <!--    </div>-->
    <!--  </div>-->
    <!--</div>-->
  </div>

<div class="row">

    <div class="col-xl-12 order-xl-1">
        <div class="card">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col-8">
                        <h3 class="mb-0">Wallet Requests</h3>
                    </div>
                    <div class="col-4 text-right">

                    </div>
                </div>
            </div>
            <div class="card-body">
                    <h4 class="heading-small text-muted mb-4">Wallet Information</h4>
                    <div class="pl-lg-4">

                       <table class=" align-items-center  table-responsive" id="squadlist">
          <thead class="thead-light">
            <tr>
              
              <th scope="col">MEMBER ID</th>
              <th scope="col">Amount</th>
              <th scope="col">Status</th>
              <th scope="col">Mode</th>
              <th scope="col">Refrence</th>
             <th scope="col"> Stock Type</th>
              <th scope="col"> Bank</th>
              <th scope="col">Narration</th>
             <th scope="col"> Type</th>
              <th scope="col"> Date</th>
            </tr>
          </thead>
        </table>



              
                    </div>
            </div>
        </div>
    </div>
</div>
